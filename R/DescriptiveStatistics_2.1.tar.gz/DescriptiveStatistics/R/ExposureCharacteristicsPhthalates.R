# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}

# quiets concerns of R CMD check when variables appear in pipelines
utils::globalVariables(c("Concentration", "LOD", "MEP", "MCNP", "Exposure"))


#' Calculates exposure characteristics
#'
#' @param input_data A data.frame containing information on exposure concentrations and <LOD
#' @param exposures_lod A character vector with exposure variables names containing info on <LOD, present in the original dataset
#' @param expo_names A character vector with 'clean' exposure variables names
#' @param LODs A dataframe containing LOD threshold for each compound
#' @param path A string defining the path to save the output
#' @param file_name A string defining specific part of the file name
#'
#' @return A data.frame with exposure descriptive statistics
#' @export
#'
#' @import dplyr
#' @import tidyr
#' @importFrom naniar replace_with_na_all
#' @importFrom stats quantile
#' @importFrom utils write.csv
#'
ExposureCharacteristicsPhthalates <- function(input_data,
                                              expo_names,
                                              exposures_lod,
                                              LODs,
                                              path,
                                              file_name) {

  # Calculate percentage of exposure samples >LOD
  expo_LOD <- dplyr::select(input_data, tidyselect::ends_with("_lod")) %>%
    dplyr::mutate_all(.funs = as.numeric) %>%
    tidyr::pivot_longer(cols = tidyselect::everything(), names_to = "Exposure", values_to = "Concentration") %>%
    dplyr::mutate(Exposure = factor(Exposure,
                                    levels = exposures_lod,
                                    labels = expo_names)) %>%
    merge(LODs, by = "Exposure")

  LOD_threshold <- dplyr::filter(expo_LOD, Exposure != "Sum_DEHP") %>% # Provide name of the molar sum
    dplyr::group_by(Exposure) %>%
    dplyr::summarise(n = sum(!is.na(Concentration)),
                     "% > LOD" = round(sum((Concentration >= LOD) * 100) / n, 1))

  # Calculate the summary of exposure concentrations

  # Non-standardized concentrations
  expo_orig <- expo_LOD %>%
    dplyr::group_by(Exposure) %>%
    dplyr::summarise(five_orig = round(stats::quantile(Concentration, na.rm = TRUE, probs = 0.05), 1),
                     median_orig = round(stats::quantile(Concentration, na.rm = TRUE, probs = 0.5), 1),
                     ninetyfive_orig = round(stats::quantile(Concentration, na.rm = TRUE, probs = 0.95), 1))

  # Standardized concentrations
  expo_sd <- dplyr::select(input_data, MEP:MCNP) %>% # Provide names of exposures
    tidyr::pivot_longer(cols = tidyselect::everything(), names_to = "Exposure", values_to = "Concentration") %>%
    dplyr::mutate(Exposure = factor(Exposure)) %>%
    dplyr::group_by(Exposure) %>%
    dplyr::summarise(five_sd = round(stats::quantile(Concentration, na.rm = TRUE, probs = 0.05), 1),
                     median_sd = round(stats::quantile(Concentration, na.rm = TRUE, probs = 0.5), 1),
                     ninetyfive_sd = round(stats::quantile(Concentration, na.rm = TRUE, probs = 0.95), 1))

  expo_char_table <- dplyr::right_join(LODs, LOD_threshold, by = "Exposure") %>%
    dplyr::right_join(expo_orig, by = "Exposure") %>%
    dplyr::right_join(expo_sd,by = "Exposure")

  # Change order of the rows
  expo_char_table <- expo_char_table[c(1, 3, 2, 4:9, 12, 10:11), ]

  write.csv(expo_char_table, here::here(path, paste0(file_name, ".csv")), row.names = FALSE)

  return(expo_char_table)
}
