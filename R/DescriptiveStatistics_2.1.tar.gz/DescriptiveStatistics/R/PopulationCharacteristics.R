#' Calculates population characteristics
#'
#' @param input_data Data frame with variables containing population characteristics
#' @param variable_list A character vector with names of population characteristics variables
#' @param path A string defining the path to save the output
#' @param file_name A string defining specific part of the file name
#'
#' @return A dataframe with population characteristics
#' @import compareGroups
#' @import dplyr
#' @importFrom here here
#' @importFrom tidyselect all_of
#' @export

PopulationCharacteristics <- function(input_data, variable_list, path, file_name) {

  data <- droplevels(input_data)

  res <- compareGroups::compareGroups(data = dplyr::select(data,
                                                           tidyselect::all_of(variable_list)),
                                      include.miss = TRUE,
                                      method = c(mother_age = 2,
                                                 gest_age = 2)) %>%
    compareGroups::createTable(show.n = TRUE)

  # Save to file
  compareGroups::export2csv(res,
                            file = here::here(path, paste0(file_name, ".csv")),
                            header.labels = c(p.overall = "p value"))

  return(res)
}

