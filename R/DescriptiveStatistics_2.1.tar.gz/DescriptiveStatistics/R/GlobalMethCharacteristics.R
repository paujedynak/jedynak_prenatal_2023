# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}

# quiets concerns of R CMD check when variables appear in pipelines
utils::globalVariables(c("gene", "methylation"))


#' Calculates characteristics of global methylation data
#'
#' @param glob_meth A data.frame with global methylation data
#' @param path A string defining the path to save the output
#' @param file_name A string defining specific part of the file name
#'
#' @return A dataframe with global methylation characteristics
#' @export
#' @importFrom stats sd

GlobalMethCharacteristics <- function(glob_meth,
                                      path,
                                      file_name) {

  glob_meth_long <- tidyr::pivot_longer(data = glob_meth,
                      cols = c("alumed", "linemed"),
                      names_to = "gene",
                      values_to = "methylation")

  # Calculate mean global methylation for Alu and LINE
  res <- glob_meth_long  %>%
    group_by(gene) %>%
    dplyr::summarise(mean_meth = round(mean(methylation), 1),
                     sd_meth = round(stats::sd(methylation), 1))

  write.csv(res, here::here(path, paste0(file_name, ".csv")))

  return(res)
}
