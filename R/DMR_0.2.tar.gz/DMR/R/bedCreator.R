#' Create bed files for each exposure from annotated EWAS result
#'
#' @param annotated_EWAS_result A data.frame with the annotated EWAS result
#' @param path A string defining the path to save the .bed files
#' @param prefix A string indicating a prefix for the bed file names
#'
#' @return One bed file per exposure
#' @export
#' @import dplyr
#' @importFrom utils write.table
#' @importFrom here here

bedCreator <- function(annotated_EWAS_result,
                       prefix,
                       path) {

  options("scipen" = 100, "digits" = 4)

  # Choose variables of interest from the annotated result of EWAS
  comb_data <- dplyr::select(annotated_EWAS_result, Exposure:Position, raw_p_value) %>%
    dplyr::mutate(chrom = as.character(Chr),
                  start = Position,
                  end = Position + 1,
                  'p-value' = raw_p_value) %>%
    dplyr::select(Exposure, CpG, chrom, start, end, 'p-value') %>%

    # Sort by chromosome and starting position
    dplyr::arrange(chrom, start) %>%

    # Split each exposure to a separate list element
    split(f = as.factor(.$Exposure))

  # Change rownames to CpG names
  comb_d <- lapply(comb_data, function(x){ row.names(x) <- as.character(x$CpG); x})

  # Remove columns: exposure and CpG
  comb_d <- lapply(comb_d, function(x){ x[, -c(1:2)]})

  # Save each list element into a .bed file
  for (i in seq_along(comb_d)) {

    utils::write.table(x = comb_d[[i]],
                       file = here::here(path, paste0(names(comb_d)[i], "_", prefix, ".bed")),
                       sep = "\t",
                       quote = FALSE,
                       row.names = FALSE,
                       col.names = TRUE)
  }
}
