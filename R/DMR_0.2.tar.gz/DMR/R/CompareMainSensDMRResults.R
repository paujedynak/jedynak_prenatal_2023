# quiets concerns of R CMD check when variables appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("expo", "conf_low", ":="))
}

#' Helper function to select CpGs associated with exposures in DMR analysis
#'
#' @param x A data.frame containing annotated result for CpGs constituting DMRs associated with phenol exposure
#' @param expo A string defining the name of the exposure
#' @return A data.frame with one column "CpG" containing only CpGs constituting DMRs associated with phenol exposure
#' @import dplyr
#'
.SelectCpGs <- function(x, expo) {
  CpG <- dplyr::filter(x, Exposure == expo) %>%
    dplyr::select(CpG)

  return(CpG)
}


#' Make a table comparing beta estimates and p values for different DMR analyses (e.g. main and sensitivity)
#'
#' @param meth_data A matrix containing methylation data
#' @param list_CpGs_in_DMRs A list whose each element is a list of CpGs constituting DMRs associated with phenol exposure. Each element represents one analysis (e.g. main EWAS, sensitivity adjusted for cell mix etc.)
#' @param list_regr_results A list whose each element is a full annotated result one analysis (e.g. main EWAS, sensitivity adjusted for cell mix etc.). It has to correspond to list_CpGs_in_DMRs
#' @param exposures A character vector specifying names of exposures used in EWAS/DMR analyses
#' @param prefixes A character vector specifying prefix that will be added to column names (to avoid names duplications), has to correspond to list_CpGs_in_DMRs and list_regr_results
#' @param path A string defining the path to save the result file
#' @param file_name A string defining file name without extension
#'
#' @return A data.frame comparing all the results and an excel file with each sheet corresponding to one exposure
#' @export
#'
#' @import dplyr
#' @importFrom xlsx write.xlsx

CompareMainSensDMRResults <- function(meth_data,
                                      list_CpGs_in_DMRs,
                                      list_regr_results,
                                      exposures,
                                      prefixes,
                                      path,
                                      file_name) {

  # Calculate mean methylation levels for each CpG
  mean_meth <- data.frame(mean_meth = colMeans(meth_data, na.rm = TRUE)) %>%
    tibble::rownames_to_column(var = "CpG")

  # Create an empty list where the results will be stored
  final_result <- list()

  # For each phenol exposure, list CpGs constituting DMRs detected as associated with phenol exposure
  for (expo in exposures) {

    # Extract CpGs from the first element of the list (dataset of reference, e.g. main EWAS analysis)
    # containing CpGs constituting DMRs associated with phenol exposure
    CpGs_in_DMRs <- .SelectCpGs(list_CpGs_in_DMRs[[1]], expo = expo)

    # Extract CpGs constituting DMRs for the remaining datasets with annotated result of DMR analyses
    for (i in 2:length(list_CpGs_in_DMRs)) {

      CpGs <- .SelectCpGs(list_CpGs_in_DMRs[[i]], expo = expo)
      CpGs_in_DMRs <- dplyr::full_join(CpGs_in_DMRs, CpGs, by = "CpG")
    }

    # If no CpGs are associated with phenol exposure, next
    if (nrow(CpGs_in_DMRs) == 0) {
      next
    }

    # Restrict annotated results to one exposure
    subsets_regr_results <- lapply(list_regr_results, function(x) dplyr::filter(x, Exposure == expo))

    # In the dataset obtained in the previous step, leave only CpGs that were detected in main and sensitivity analyses as associated with phenol exposure
    subsets_to_merge <- lapply(subsets_regr_results, function(x) dplyr::filter(x, CpG %in% CpGs_in_DMRs$CpG))

    # Choose variables of interest (in the dataset of reference which is the first one in the list) to start building the final table
    subsets_to_merge[[1]] <- subsets_to_merge[[1]] %>%
      dplyr::select(Exposure:Gene, Estimate, raw_p_value, p_value_FDR)

    # Change column names to avoid duplications of column names
    colnames(subsets_to_merge[[1]])[c(6:8)] <- paste(colnames(subsets_to_merge[[1]])[c(6:8)], prefixes[1], sep = "_")

    # From the remaining datasets restricted to CpGs of interest, choose the variables of interest and change their names to avoid duplication in column names
    for (j in 2:length(subsets_to_merge)) {

      subsets_to_merge[[j]] <- dplyr::select(subsets_to_merge[[j]], CpG, Estimate, raw_p_value, p_value_FDR)
      colnames(subsets_to_merge[[j]])[-1] <- paste(colnames(subsets_to_merge[[j]][-1]), prefixes[j], sep = "_")

    }

    # Merge first (reference) dataset with the second one
    expo_res <- merge(subsets_to_merge[[1]], subsets_to_merge[[2]], by = "CpG") %>%

      # Calculate difference between estimates of dataset 1 (reference) and 2
      dplyr::mutate(!!dplyr::sym(paste0("diff_", prefixes[2])) :=
                      -((!!dplyr::sym(paste0("Estimate_", prefixes[1])) -
                           !!dplyr::sym(paste0("Estimate_", prefixes[2]))) * 100) /
                      !!dplyr::sym(paste0("Estimate_", prefixes[1])),
                    !!dplyr::sym(paste0("diff_", prefixes[2])) := round(!!dplyr::sym(paste0("diff_", prefixes[2])), 1),
                    !!dplyr::sym(paste0("diff_abs_",prefixes[2])) := abs(!!dplyr::sym(paste0("diff_",  prefixes[2]))))

    # Merge remaining datasets
    if (length(subsets_to_merge) >= 3) {

      for (k in 3:length(subsets_to_merge)) {

        expo_res <- merge(expo_res, subsets_to_merge[[k]], by = "CpG") %>%

          # Calculate difference between estimates of dataset 1 (reference) and remaining datasets
          dplyr::mutate(!!dplyr::sym(paste0("diff_", prefixes[k])) :=
                          -((!!dplyr::sym(paste0("Estimate_", prefixes[1])) -
                               !!dplyr::sym(paste0("Estimate_", prefixes[k]))) * 100) /
                          !!dplyr::sym(paste0("Estimate_", prefixes[1])),
                        !!dplyr::sym(paste0("diff_", prefixes[k])) := round(!!dplyr::sym(paste0("diff_", prefixes[k])), 1),
                        !!dplyr::sym(paste0("diff_abs_", prefixes[k])) := abs(!!dplyr::sym(paste0("diff_", prefixes[k]))))
      }
    }

    # Add information on the methylation level for each CpG
    expo_res <- merge(expo_res, mean_meth, by = "CpG")

    # Append a sheet to the excel storing results
    xlsx::write.xlsx(expo_res,
                     file = here::here(path, paste0(file_name, ".xlsx")),
                     sheetName = expo,
                     append = TRUE,
                     row.names = FALSE)

    # Append the list of results
    final_result[[length(final_result) + 1]] <- expo_res
  }

  return(final_result)
}
