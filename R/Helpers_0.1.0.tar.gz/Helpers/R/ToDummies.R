# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}

#' Converts categorical variables to dummies
#'
#' @param data A data frame containing variables to be converted
#'
#' @return A data frame containing categorical variables converted to dummies
#' @export
#'
#' @import dplyr
#' @import tibble
#' @importFrom fastDummies dummy_cols

ToDummies <- function(data) {

  dummy_var <- data %>%

    # Change categorical variables to dummy variables
    fastDummies::dummy_cols(select_columns = colnames(dplyr::select_if(., is.factor)),
                            remove_first_dummy = TRUE) %>%
    tibble::remove_rownames() %>%
    tibble::column_to_rownames(var = "id") %>%
    dplyr::select_if(is.numeric) %>%

    # Change data to matrix
    data.matrix()

  return(dummy_var)
}
