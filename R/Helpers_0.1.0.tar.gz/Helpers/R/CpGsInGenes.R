# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("Gene", "."))
}

#' Split CpGs for genes that has multiple splice variants
#'
#' @param data A data.frame containing info on CpGs and corresponding genes
#' @param var_to_distinct A string defining name of the variable to keep as unique
#'
#' @return A data.frame with duplicated CpGs for each splice variant of a gene
#' @export
#' @import dplyr
#' @importFrom stringr str_split
#' @importFrom tidyr unnest_longer
#' @importFrom stats na.omit

CpGsInGenes <- function(data, var_to_distinct) {

  split_genes <- data %>%
    dplyr::mutate(Gene = stringr::str_split(.data$Gene, ";")) %>%
    tidyr::unnest_longer(.data$Gene) %>%
    dplyr::distinct(!!dplyr::sym(var_to_distinct), .keep_all = TRUE) %>%
    stats::na.omit() %>%
    dplyr::filter(Gene != "Unknown") %>%
    dplyr::ungroup()

  return(split_genes)
}
