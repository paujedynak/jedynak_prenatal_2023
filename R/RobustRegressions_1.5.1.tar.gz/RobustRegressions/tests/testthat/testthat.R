library(testthat)
library(RobustRegressions)

testthat::test_check("RobustRegressions")
