# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c(".", "var", "%dopar%"))
}

#' Annotated results of the robust linear regressions for mean methylation level in function of exposure concentration
#'
#' @param expo_cov A data.frame containing all variables needed for regression (exposures and confounders)
#' @param confounders A character vector containing names of the confounders
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#' @param path Path for saving the result file
#' @param file_name File name without extension
#' @param meth_data A matrix containing methylation data
#' @param exposures A character vector naming the exposures
#' @param ncores The number of cores used for parallel computing, by default all available cores
#' @param annotation_object An Illumina object used to annotate files
#' @param expo_labels A character vector containing full names of exposures
#'
#' @return A data.frame with annotated statistics for each CpG: beta estimate for the association with exposure; uncorrected and corrected p values; average mean meth level with SE;
#' @export
#' @import dplyr
#' @import here
#' @import parallel
#' @import stringr
#' @importFrom stats p.adjust
#' @importFrom rlang .data
#' @importFrom doParallel registerDoParallel
#' @importFrom foreach registerDoSEQ
#' @importFrom tibble rownames_to_column
#' @importFrom data.table fwrite
#' @importFrom bigstatsr nb_cores

SpecificLociMethylationRegressions <-
  function(meth_data,
           expo_cov,
           exposures,
           confounders,
           technical_confounders,
           maxit,
           ncores = bigstatsr::nb_cores(),
           annotation_object,
           expo_labels,
           path,
           file_name) {

    # Set the parallel computing conditions
    # Check the operating system

    if (Sys.info()[["sysname"]] == "Windows") {
      # Set the parallel computing conditions for WINDOWS

      # Create a set of copies of R running in parallel and communicating over sockets
      cl <- parallel::makeCluster(getOption("cl.cores", ncores))
      parallel::clusterEvalQ(cl, library("magrittr"))

      # Register the parallel backend
      doParallel::registerDoParallel(cl)

      # Explicitly register a sequential parallel backend. This will prevent a warning message
      # from being issued if the %dopar% function is called and no parallel backend has been registered.
      foreach::registerDoSEQ()

      # Stop the cluster
      on.exit(parallel::stopCluster(cl))

      # Check if methylation data is paired with phenotype data
      if (!identical(rownames(meth_data), expo_cov$id)) {
        stop("The rownames of the methylation data do not match IDs in phenotypic data")
      }

      # 1. Run robust linear regressions for each CpG in function of exposure, adjusted for covariates

      # Create an object where regression results for all exposures will be stored

      res_all_expo <- list()

      for (i in seq_along(exposures)) {

        cat("Progress:", i, "/", length(exposures), "exposures\n")

        # Run robust linear regressions separately for each CpG and adjust p values for multiple testing
        result_loci_regr <- parallel::parApply(
          cl = cl,
          X = meth_data,
          MARGIN = 2,
          FUN = .RobustLinearRegressionLoci,
          exposure = exposures[i],
          expo_cov = expo_cov,
          confounders = confounders,
          technical_confounders = technical_confounders,
          maxit = maxit
        )

        # Transform results for an exposure into a data frame
        result_loci_regr_df <- result_loci_regr %>%
          do.call(rbind, .) %>%
          as.data.frame() %>%
          tibble::rownames_to_column("CpG") %>%
          dplyr::mutate(Exposure = exposures[i])

        # Adjust p values
        result_loci_regr_table <- .AdjustPvalues(result_loci_regr_df = result_loci_regr_df,
                                                 method = "BH")

        # Append the result list
        res_all_expo[[i]] <- result_loci_regr_table
        names(res_all_expo)[i] <- exposures[i]
      }

      # 2. Annotate the results with the illumina annotation file

      annot_result <- .MakeAnnotTable(
        regr_result = res_all_expo,
        annotation_object = annotation_object,
        exposures = exposures,
        expo_labels = expo_labels
      )

    } else {

      # Register parallel process
      doParallel::registerDoParallel(ncores)
      on.exit(doParallel::stopImplicitCluster(), add = TRUE)

      # 1. Run robust linear regressions for each CpG in function of exposure, adjusted for covariates

      # Run robust linear regressions separately for each CpG and adjust p values for multiple testing
      result_loci_regr <- foreach::foreach(var = exposures,
                                           .combine = "cbind",
                                           .packages = "magrittr") %dopar%

        {
          apply(X = meth_data,
                MARGIN = 2,
                FUN = .RobustLinearRegressionLociForeach,
                exposure = var,
                expo_cov = expo_cov,
                confounders = confounders,
                technical_confounders = technical_confounders,
                maxit = maxit)
        }

      # Transform results for an exposure into a data frame
      result_loci_regr_df <- result_loci_regr %>%
        do.call(rbind, .) %>%
        dplyr::mutate(CpG = rep(colnames(meth_data), length(exposures))) %>%
        dplyr::select(.data$Exposure, .data$CpG, tidyselect::everything())

      # Adjust p values
      result_loci_regr_table <- .AdjustPvaluesForeach(result_loci_regr_df = result_loci_regr_df,
                                                      method = "BH")

      # 2. Annotate the results with the illumina annotation file

      annot_result <- .MakeAnnotTableForeach(
        regr_result = result_loci_regr_table,
        annotation_object = annotation_object,
        exposures = exposures,
        expo_labels = expo_labels
      )
    }


    # 3. Save the annotated result to a file
    saveRDS(annot_result, file = here::here(path, paste0(file_name, ".RDS")))

    # 4. Save the confounders set and the technical confounders set to a file
    data.table::fwrite(list(confounders),
                       file = here::here(path, paste0(file_name, "_confounders.txt")))
    data.table::fwrite(list(technical_confounders),
                       file = here::here(path, paste0(file_name, "_technical_confounders.txt")))

    return(annot_result)
  }
