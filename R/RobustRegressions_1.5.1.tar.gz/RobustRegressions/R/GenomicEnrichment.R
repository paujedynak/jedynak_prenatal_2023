# quiets concerns of R CMD check when variables appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("CpG", "Mean_meth_SE"))
}

#' Enrich regression result with average mean methylation level and CpG state (hyper- or hypomethylated)
#'
#' @param meth_data A matrix containing methylation data
#' @param result_restr_FDR Regression result limited to significant associations between exposure and methylation level (p_value_FDR < 0.05)
#'
#' @return A data.frame enriched with information on average mean methylation level and CpG state (hyper- or hypomethylated)
#' @export
#'
#' @import dplyr
#' @import utils
#' @importFrom stats sd
#' @importFrom tibble rownames_to_column
#' @importFrom stats na.omit
#' @importFrom rlang .data
#'

EnrichRegrResult <- function(meth_data, result_restr_FDR) {

  # Calculate average mean methylation level and its SE for each subject

  if (nrow(result_restr_FDR) > 1) {

    # Calculate mean methylation level for the sample (across all patients) for the significanly methylated CpGs
    mean_meth <-
      apply(meth_data[, unique(result_restr_FDR$CpG)], 2, function(x)
        round(mean(x, na.rm = TRUE), 3))

    # Calculate SE of the methylation level for the sample (across all patients)
    se_mean_meth <-
      apply(meth_data[, unique(result_restr_FDR$CpG)], 2, function(x)
        round(stats::sd(x, na.rm = TRUE) / sqrt(length(
          stats::na.omit(x)
        )), 3))

    # Bind the mean and SE vectors by CpG names
    mean_se <-
      cbind(mean_meth, se_mean_meth = se_mean_meth[names(mean_meth)]) %>%
      as.data.frame() %>%
      tibble::rownames_to_column("CpG") %>%

      # Create a vector containing a common statistic for the mean methylation value: its average and SE
      dplyr::mutate(Mean_meth_SE = paste0(mean_meth, " (", se_mean_meth, ")"))

    # Merge annotated dataset with mean methylation data
    data_meth_level <-
      merge(result_restr_FDR, mean_se[, c("CpG", "Mean_meth_SE")], by = "CpG")

  } else {

    # Calculate mean methylation level for the sample (across all patients) for the significanly methylated CpG
    mean_meth <- meth_data[, unique(result_restr_FDR$CpG)] %>%
      mean(., na.rm = TRUE) %>%
      round(3)

    # Calculate SE of the methylation level for the sample (across all patients)
    se_mean_meth <- meth_data[, unique(result_restr_FDR$CpG)]
    se_mean_meth <- stats::sd(se_mean_meth, na.rm = TRUE) / sqrt(length(stats::na.omit(se_mean_meth)))

    # Bind the mean and SE vectors by CpG name
    mean_se <-
      cbind(mean_meth, se_mean_meth) %>%
      as.data.frame() %>%
      dplyr::mutate(CpG = result_restr_FDR$CpG) %>%

      # Create a vector containing a common statistic for the mean methylation value: its average and SE
      dplyr::mutate(Mean_meth_SE = paste0(mean_meth, " (", se_mean_meth, ")")) %>%
      dplyr::select(CpG, mean_meth:Mean_meth_SE)

    data_meth_level <- merge(result_restr_FDR, mean_se[, c("CpG", "Mean_meth_SE")], by = "CpG")

  }

  # Add the information on the CpG state (hypo= or hypermethylation) and change Location_of_CpG in reference to gene island to factor

  # Name the levels and labels of the variable Location_in_gene that will be changed to factor
  CpG_levels <-
    c("Island",
      "S_Shore",
      "N_Shore",
      "S_Shelf",
      "N_Shelf",
      "OpenSea")

  CpG_labels <-
    c("Island",
      "South Shore",
      "North Shore",
      "South Shelf",
      "North Shelf",
      "Open Sea")

  data_enrichment <- data_meth_level %>%

    # Add variable defining if significanly differentially methylated CpG is hypo- or hypermethylated
    dplyr::mutate(
      CpG_state = factor(
        dplyr::case_when(.data$Estimate < 0 ~ "Hypomethylated",
                         TRUE ~ "Hypermethylated")
      ),

      # Change Location_of_CpG to factor with new labels
      Location_of_CpG = factor(
        .data$Location_of_CpG,
        levels = CpG_levels,
        labels = CpG_labels
      )
    )

  return(data_enrichment)
}


#' Change CpG locations (relative to island and gene) and methylation status to factor
#'
#' @param data A data.frame with not annotated results containing beta estimates for each exposure
#'
#' @return A data.frame with an annotated file ready to plot the CpG locations in function of the methylation status
#' @export
#' @import dplyr
#' @import tidyr
#' @import here
#' @importFrom stringr str_split
#' @importFrom rlang .data

CpgLocations <- function(data) {

  # Name the levels and labels of the variable Location_in_gene that will be changed to factor
  gene_levels <- c("No group", "TSS200", "TSS1500", "Body", "5'UTR", "3'UTR", "1stExon")
  gene_labels <- c("No group", "200bp from TSS", "1500bp from TSS", "Gene Body", "5' UTR", "3' UTR", "First Exon")

  # Split information on CpG location in reference to gene
  CpG_location_gene <- data %>%

    dplyr::mutate(Location_in_gene = stringr::str_split(.data$Location_in_gene, ";")) %>%
    tidyr::unnest_longer(.data$Location_in_gene) %>%

    # Change Location_in_gene to factor with new labels
    dplyr::mutate(Location_in_gene = factor(.data$Location_in_gene, levels = gene_levels, labels = gene_labels))

  # Split information on gene
  genes <- data %>%

    dplyr::mutate(Gene = stringr::str_split(.data$Gene, ";")) %>%
    tidyr::unnest_longer(.data$Gene) %>%

    # Change Location_in_gene to factor with new labels
    dplyr::mutate(Gene = factor(.data$Gene))

  data_location_CpG_gene <- list(CpG_location_gene, genes)

  return(data_location_CpG_gene)
}


#' Calculate number and percentage of hypo- and hypermethylated CpGs for each esxposure
#'
#' @param data A data.frame containing annotated file including methylation status and CpG location in relation to island and gene
#' @param path A string defining the path to save the output
#' @param file_name A string defining specific part of the file name
#'
#' @return A data.frame containing number and percentage of hypo- and hypermethylated CpGs for each esxposure
#' @export
#'
#' @import dplyr
#' @importFrom utils write.csv
#' @importFrom rlang .data

CountDiffMeth <- function(data, path, file_name) {

  meth_status_count <- data %>%
    dplyr::group_by(.data$Exposure_name, .data$CpG_state) %>%

    # Summarise the number of differentially methylated CpGs and genes
    dplyr::summarise(meth_status_cpgs = n_distinct(.data$CpG),
                     meth_status_gene = n_distinct(.data$Gene)) %>%

    dplyr::mutate(meth_status_cpg_perc =
                    round(100 * (.data$meth_status_cpgs / sum(.data$meth_status_cpgs)), 1),
                  meth_status_gene_perc =
                    round(100 * (.data$meth_status_gene / sum(.data$meth_status_gene)), 1)) %>%
    dplyr::select(.data$Exposure_name:.data$meth_status_cpgs,
                  .data$meth_status_cpg_perc,
                  .data$meth_status_gene,
                  .data$meth_status_gene_perc)

  utils::write.csv(meth_status_count, here::here(path, paste0(file_name, ".csv")))

  return(meth_status_count)
}
