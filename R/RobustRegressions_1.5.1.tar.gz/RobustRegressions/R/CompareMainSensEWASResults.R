# quiets concerns of R CMD check when variables appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c(".", "Exposure", "Gene", "p_value_FDR", "raw_p_value", "Estimate_main",
                           "Estimate_cellmix", "Estimate_smoke", "Estimate_deliv", "Estimate_pathol"))
}

#' Make a table comparing beta estimates and p values for different EWAS analyses (e.g. main and sensitivity)
#'
#' @param annotated_EWAS_results A list of data.frame with the annotated EWAS results for main and sensitivity analyses
#' @param exposures A character vector specifying names of exposures used in EWAS/DMR analyses
#' @param path A string defining the path to save the result file
#' @param file_name A string defining file name without extension
#'
#' @export
#' @return A data.frame with one column "CpG" containing only CpGs constituting DMRs associated with phenol exposure
#' @import dplyr
#' @importFrom xlsx write.xlsx
#' @importFrom here here


CompareMainSensEWASResults <- function(annotated_EWAS_results,
                                       exposures,
                                       path,
                                       file_name) {

  # Prepare main results
  # Select all significant EWAS results for TCS
  EWAS_result_TCS <- annotated_EWAS_results$main %>%
    dplyr::filter(p_value_FDR < 0.05, Exposure == "TCS_log2") %>%
    dplyr::select(Exposure:Gene, Estimate, raw_p_value, p_value_FDR)

  # Select 20 top significant results for other phenols
  EWAS_result_phenols <- annotated_EWAS_results$main %>%
    dplyr::group_by(Exposure) %>%
    dplyr::filter(Exposure != "TCS_log2") %>%
    dplyr::arrange(raw_p_value) %>%
    dplyr::slice(1:20) %>%
    dplyr::select(Exposure:Gene, Estimate, raw_p_value, p_value_FDR)

  # Merge results
  EWAS_results <- rbind(EWAS_result_TCS, EWAS_result_phenols) %>%
    dplyr::arrange(Exposure, CpG)

  # Prepare sensitivity results - choose only columns with Exposure, CpG, beta and pvalues
  annotated_EWAS_results[["main"]] <- NULL
  
  sens_res <- annotated_EWAS_results %>%
    lapply(function(x) dplyr::select(x, Exposure, CpG, Estimate, raw_p_value, p_value_FDR))

  # Combine all results into one list
  sens_res[["main"]] <- EWAS_results

  # Change names of the columns so they do not duplicate
  for (i in seq_along(names(sens_res))) {
    sens_res[[i]] <- dplyr::rename_at(sens_res[[i]], vars(Estimate:p_value_FDR), function(x) paste(x, names(sens_res)[i], sep = "_"))
  }

  # For each exposure make a table comparing estimates and p values and save it as an excel tab
  for (expo in exposures) {

    # Select one exposure
    temp <- lapply(sens_res, function(x) dplyr::filter(x, Exposure == expo)) %>%
      lapply(function(x) dplyr::select(x, -Exposure))

    # Merge all datasets into one
    final <- merge(temp$main, temp$pathol, by = "CpG") %>%

      # Calculate difference between estimates of dataset 1 (reference) and 2
      dplyr::mutate("diff_abs_pathol" = round(abs((Estimate_main - Estimate_pathol) * 100 / Estimate_main), 1))

    # Write the result to the file
    xlsx::write.xlsx(final,
                     file = here::here(path, paste0(file_name, ".xlsx")),
                     sheetName = expo,
                     append = TRUE,
                     row.names = FALSE)
  }
  
  return(final)
}
