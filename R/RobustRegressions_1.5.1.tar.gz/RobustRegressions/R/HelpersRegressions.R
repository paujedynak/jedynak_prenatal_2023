# quiets concerns of R CMD check when variables appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c(".", "exposures", "expo_labels", "Estimate", "term"))
}


#' Fit the robust linear regression
#'
#' @param formula A formula defining the elements of the regression
#' @param data A data.frame containing global methylation variable, exposure variables, confounders and technical confounders
#' @param maxit The number of iterations for each robust regression
#' @importFrom MASS rlm
#'
#' @return An object created by MASS:mlr robust linear regression function

.RobustLinearRegression <- function(formula, data, maxit) {
  fit <- MASS::rlm(formula = formula,
                   data = data,
                   maxit = maxit)
  return(fit)
}



#' Obtain regression statistics for one
#'
#'
#' @param fit An object created by MASS:mlr robust linear regression function
#' @param data A data.frame containing a subset of methylation data of one CpG (y) and exposure-covariates data (x)
#' @param exposure A string with the exposure name
#' @import survey
#' @importFrom stats confint.default
#' @importFrom broom tidy
#' @importFrom rlang .data
#'
#' @return A data.frame containing results of the regression for one model for one exposure

.ObtainStatistics <- function(fit, data, exposure) {

  # Calculate p values using Wald test
  wald <-
    survey::regTermTest(model = fit,
                        test.terms = exposure,
                        null = NULL,
                        df = Inf,
                        method = "Wald")

  # Extract exposure name (it will be identical to "exposure" argument for continuous exposures
  # but different for a categorical exposures)
  expo <- broom::tidy(fit) %>%
    dplyr::filter(stringr::str_detect(term, exposure)) %>%
    dplyr::pull(term)

  # Calculate CIs
  CIs <-
    stats::confint.default(object = fit,
                           parm = expo,
                           level = 0.95) %>%
    as.data.frame() %>%
    dplyr::rename(conf_low = .data$`2.5 %`, conf_high = .data$`97.5 %`)

  # Obtain estimate with it 95% CI
  Estimate_CI <- paste0(
    format(round(fit$coefficients[expo], 4), nsmall = 4, scientific = FALSE),
    " (",
    format(round(CIs$conf_low, 4), nsmall = 4, scientific = FALSE),
    ";",
    format(round(CIs$conf_high, 4), nsmall = 4, scientific = FALSE),
    ")"
  )

  # Obtain estimate
  Estimate <- fit$coefficients[expo]

  # Obtain standard error of the estimate (assuming that the exposure coefficient is in the second row)
  SE <- summary(fit)$coefficients[expo, "Std. Error"]

  # Combine estimates, CIs and p values
  sfit <-
    cbind(
      Estimate,
      SE,
      CIs,
      Estimate_CI,
      raw_p_value = as.numeric(wald$p)
    )

  return(sfit)
}



#' Run robust linear regression for methylation at specific loci ~ 1 exposure at a time (ExWAS) adjusted for diferent set of confounders
#'
#' @param expo_cov A data.frame containing all variables needed for regression (exposures and confounders)
#' @param exposure A character string with the exposure name
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#' @param CpG A numeric vector containing methylation data from 1 CpG
#' @param confounders A character vector containing names of the confounders
#'
#' @importFrom stats as.formula p.adjust sd
#' @importFrom rlang .data
#' @importFrom tibble column_to_rownames
#'
#' @return A named vector of p values for regressions for each CpG

.RobustLinearRegressionLoci <-
  function(CpG,
           exposure,
           expo_cov,
           confounders = 0,
           technical_confounders = 0,
           maxit) {

    # Keeping CpG as a matrix will preserve the row names (apply coerces it to numeric vector)
    CpG <- as.matrix(CpG)

    # Change the CpG colname name to "y" as it will be used as such in the regression formula
    colnames(CpG) <- "y"

    # Change ID to rownames so covariates can be merged with methylation dataset
    expo_cov <- expo_cov %>%
      tibble::column_to_rownames(var = "id")

    # Create a subset of data containing methylation data of one CpG (y) and exposure-covariates data (x)
    data <- merge(x = expo_cov, y = CpG, by = "row.names")

    # Create regression formula
    formula <-
      stats::as.formula(paste(
        "y ~",
        exposure,
        "+",
        paste(confounders, collapse = " + "),
        "+",
        paste(technical_confounders, collapse = " + ")
      ))

    # Fit the robust linear regression for one exposure at a time
    fit <- .RobustLinearRegression(formula = formula,
                                   data = data,
                                   maxit = maxit)

    # Obtain regression statistics
    sfit <- .ObtainStatistics(fit = fit,
                              data = data,
                              exposure = exposure)

    return(sfit)
  }


#' Run robust linear regression (parallel using foreach) for methylation at specific loci ~ 1 exposure at a time (ExWAS) adjusted for diferent set of confounders
#'
#' @param expo_cov A data.frame containing all variables needed for regression (exposures and confounders)
#' @param exposure A character string with the exposure name
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#' @param CpG A vector containing methylation data from 1 CpG
#' @param confounders A character vector containing names of the confounders
#'
#' @importFrom stats as.formula p.adjust sd
#' @importFrom rlang .data
#'
#' @return A named vector of p values for regressions for each CpG

.RobustLinearRegressionLociForeach <-
  function(CpG,
           exposure,
           expo_cov,
           confounders = 0,
           technical_confounders = 0,
           maxit) {

    # Obtain regression statistics
    sfit <- .RobustLinearRegressionLoci(CpG,
                                        exposure,
                                        expo_cov,
                                        confounders,
                                        technical_confounders,
                                        maxit)

    # Transform results for an exposure into a data frame
    sfit_df <- sfit %>%
      as.data.frame() %>%
      tibble::rownames_to_column("Exposure")

    return(sfit_df)
  }



#' Adjust p values for multiple testing
#'
#' @param result_loci_regr_df A data.frame of uncorrected p values for regressions for each CpG
#' @param method Correction method, a character string. Can be abbreviated.
#'
#' @return A data.frame of uncorrected and corrected p values for regressions for each CpG
#' @importFrom rlang .data
#' @seealso [p.adjust()] for p values adjustment method
#'

.AdjustPvalues <- function(result_loci_regr_df, method) {

  result_loci_regr_table <- result_loci_regr_df %>%
    dplyr::mutate(

      # Add Benjamini-Hochberg corrected p value
      p_value_FDR = stats::p.adjust(
        .data$raw_p_value,
        method = method
      )
    )

  return(result_loci_regr_table)
}



#' Adjust p values for multiple testing (parallelized using foreach)
#'
#' @param result_loci_regr_df A data.frame of uncorrected p values for regressions for each CpG
#' @param method Correction method, a character string. Can be abbreviated.
#'
#' @return A data.frame of uncorrected and corrected p values for regressions for each CpG
#' @importFrom rlang .data
#' @seealso [p.adjust()] for p values adjustment method
#'

.AdjustPvaluesForeach <- function(result_loci_regr_df, method) {

  result_loci_regr_table <- result_loci_regr_df %>%
    dplyr::group_by(.data$Exposure) %>%
    dplyr::mutate(

      # Add Benjamini-Hochberg corrected p value
      p_value_FDR = stats::p.adjust(
        .data$raw_p_value,
        method = method
      )
    ) %>%
    dplyr::ungroup()

  return(result_loci_regr_table)
}


#' Create an annotation table
#'
#' @param annotation_object Annotation object (Illumina)
#' @param regr_result A data.frame containing regression results
#' @param exposures A character vector naming the exposures
#' @param expo_labels A character vector providing full names of the exposures
#'
#' @return A data.frame containing annotated CpGs
#' @importFrom minfi getAnnotation
#' @importFrom stringr str_remove
#'

.MakeAnnotTable <-
  function(regr_result,
           annotation_object,
           exposures,
           expo_labels) {
    # Create an object to store annotated result
    annot_result <- data.frame()

    for (i in seq_along(regr_result)) {

      # Careful with assigning p values: if minfi::getAnnotation orderByLocation = TRUE,
      # the p values will not be assigned correctly!!
      an_table <- minfi::getAnnotation(
        object = annotation_object,
        lociNames = regr_result[[i]][, "CpG"],
        orderByLocation = FALSE
      )

      res <- data.frame(
        Exposure = names(regr_result[i]),
        CpG = an_table$Name,
        Chr = factor(
          stringr::str_remove(an_table$chr, "chr"),
          levels = c(as.character(1:22), "X", "Y")
        ),
        Position = an_table$pos,
        Gene = an_table$UCSC_RefGene_Name,
        Location_of_CpG = an_table$Relation_to_Island,
        Location_in_gene = an_table$UCSC_RefGene_Group,
        Estimate = regr_result[[i]][, "Estimate"],
        Est_SE = regr_result[[i]][, "SE"],
        Estimate_CI = regr_result[[i]][, "Estimate_CI"],
        conf_low = regr_result[[i]][, "conf_low"],
        conf_high = regr_result[[i]][, "conf_high"],
        raw_p_value = regr_result[[i]][, "raw_p_value"],
        p_value_FDR = regr_result[[i]][, "p_value_FDR"],
        stringsAsFactors = FALSE
      )

      annot_result <- dplyr::bind_rows(annot_result, res)
    }

    annot_result_full <- annot_result %>%
      dplyr::mutate(Exposure_name = factor(.data$Exposure,
                                           levels = exposures,
                                           labels = expo_labels)) %>%
      dplyr::arrange(.data$Exposure_name, .data$CpG)

    # Replace empty gene record by "Unknown"
    annot_result_full$Gene[annot_result_full$Gene == ""] <- "Unknown"
    annot_result_full$Location_in_gene[annot_result_full$Location_in_gene == ""] <-
      "No group"

    return(annot_result_full)
  }




#' Create an annotation table
#'
#' @param annotation_object Annotation object (Illumina)
#' @param regr_result A data.frame containing regression results
#' @param exposures A character vector naming the exposures
#' @param expo_labels A character vector providing full names of the exposures
#'
#' @return A data.frame containing annotated CpGs
#' @importFrom minfi getAnnotation
#' @importFrom stringr str_remove
#'

.MakeAnnotTableForeach <-
  function(regr_result,
           annotation_object,
           exposures,
           expo_labels) {

    # Create an object to store annotated result
    annot_result <- data.frame()

    for (expo in unique(exposures)) {

      regr_result_subset <- regr_result %>%
        dplyr::filter(.data$Exposure == expo)

      # Careful with assigning p values: if minfi::getAnnotation orderByLocation = TRUE,
      # the p values will not be assigned correctly!!
      an_table <- minfi::getAnnotation(
        object = annotation_object,
        lociNames = as.matrix(regr_result_subset[, "CpG"]),
        orderByLocation = FALSE
      )

      res <- data.frame(
        Exposure = expo,
        CpG = an_table$Name,
        Chr = factor(
          stringr::str_remove(an_table$chr, "chr"),
          levels = c(as.character(1:22), "X", "Y")
        ),
        Position = an_table$pos,
        Gene = an_table$UCSC_RefGene_Name,
        Location_of_CpG = an_table$Relation_to_Island,
        Location_in_gene = an_table$UCSC_RefGene_Group,
        Estimate = regr_result_subset[, "Estimate"],
        Est_SE = regr_result_subset[, "SE"],
        Estimate_CI = regr_result_subset[, "Estimate_CI"],
        conf_low = regr_result_subset[, "conf_low"],
        conf_high = regr_result_subset[, "conf_high"],
        raw_p_value = regr_result_subset[, "raw_p_value"],
        p_value_FDR = regr_result_subset[, "p_value_FDR"],
        stringsAsFactors = FALSE
      )

      annot_result <- dplyr::bind_rows(annot_result, res)
    }

    annot_result_full <- annot_result %>%
      dplyr::mutate(Exposure_name = factor(.data$Exposure,
                                           levels = exposures,
                                           labels = expo_labels)) %>%
      dplyr::arrange(.data$Exposure_name, .data$CpG)

    # Replace empty gene record by "Unknown"
    annot_result_full$Gene[annot_result_full$Gene == ""] <- "Unknown"
    annot_result_full$Location_in_gene[annot_result_full$Location_in_gene == ""] <-
      "No group"

    return(annot_result_full)
  }



#' Obtain regression statistics for all models
#'
#' @param res A data.frame containing results of the regression for one model
#' @param exposures A character vector containing names of the exposures
#'
#' @importFrom rlang .data
#' @import dplyr
#'
#' @return A data.frame containing cleaned results of the regression for one model

.CleanResults <- function(res, exposures) {
  clean_res <- res %>%
    dplyr::mutate(
      Exposure = exposures,
      Estimate = format(round(.data$Estimate, 3), nsmall = 3, scientific = FALSE),
      SE = format(round(.data$SE, 3), nsmall = 3, scientific = FALSE),
      Beta_SE = paste0(.data$Estimate, " (", .data$SE, ")"),
      Estimate = as.numeric(Estimate),
      SE = as.numeric(SE),
      raw_p_value = as.numeric(format(round(.data$raw_p_value, 3), nsmall = 3, scientific = FALSE)),
      conf_low = as.numeric(format(round(.data$conf_low, 4), nsmall = 4, scientific = FALSE)),
      conf_high = as.numeric(format(round(.data$conf_high, 4), nsmall = 4, scientific = FALSE))
    )

  return(clean_res)
}



#' Save regression statistics
#'
#' @param result A data.frame containing cleaned results of the regression for one model
#' @param global_meth A string defining global methylation name
#' @param path A string defining the path to save the output
#' @param file_name A string defining specific part of the file name
#' @importFrom  here here
#' @importFrom  utils write.csv

.SaveStatistics <- function(result, global_meth, path, file_name) {

  # Save results to a file
  full_file_name <- paste0(global_meth, "_", file_name, ".csv")

  # Save the result to a file
  write.csv(result, here::here(path, full_file_name))
}

#' Conducts non-linearity test for a single CpG
#'
#' @param CpG A vector containing methylation data from 1 CpG
#' @param exposure A character string with the exposure nam
#' @param expo_cov A data.frame containing all variables needed for regression (exposures and confounders)
#' @param knots A scalar defining the number of knots for the rcs function (see help for parms in the rms::rcs function). Default = 3. Only values between 3 and 5 are accepted
#' @param confounders A character vector containing names of the confounders
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#'
#' @return A data.frame with different p-values for one CpG: total, linear, non-linear and FDR corrected p-value for total (linear and non-linear associations)
#' @import dplyr
#' @importFrom tibble column_to_rownames
#' @importFrom stats as.formula
#' @importFrom sfsmisc f.robftest
#' @importFrom rms rcs

.NonLinearity <- function(CpG,
                          exposure,
                          expo_cov,
                          knots = knots,
                          confounders = 0,
                          technical_confounders = 0,
                          maxit) {

  # Keeping CpG as a matrix will preserve the row names (apply coerces it to numeric vector)
  CpG <- as.matrix(CpG)

  # Change the CpG colname name to "y" as it will be used as such in the regression formula
  colnames(CpG) <- "y"

  # Change ID to rownames so covariates can be merged with methylation dataset
  expo_cov_data <- expo_cov %>%
    tibble::column_to_rownames(var = "id")

  # Create a subset of data containing methylation data of one CpG (y) and exposure-covariates data (x)
  data <- merge(x = expo_cov_data, y = CpG, by = "row.names")

  # Create regression formula
  formula <-
    stats::as.formula(paste(
      "y ~ rms::rcs(",
      exposure,
      ", ",
      knots,
      ") +",
      paste(confounders, collapse = " + "),
      "+",
      paste(technical_confounders, collapse = " + ")
    ))

  # Fit the robust linear regression for one exposure at a time
  cs_fit <- MASS::rlm(formula = formula,
                      data = data,
                      maxit = maxit)

  # # To determine the positions of the knots:
  # xd <- Hmisc::rcspline.eval(expo_cov_data$aver_log2_MECPP, nk = 5)
  # p = attr(xd, "knots")
  #
  # # To recalculate percentiles for each knot:
  # stats::ecdf(expo_cov_data$aver_log2_MECPP)(p)

  if (knots == 5) {
    spline_tot <- sfsmisc::f.robftest(cs_fit, var = 2:5)$p.value # total
    spline_lin <- sfsmisc::f.robftest(cs_fit, var = 2)$p.value # linear
    spline_nonl <- sfsmisc::f.robftest(cs_fit, var = 3:5)$p.value # non linear

    spline_tot_stat <- sfsmisc::f.robftest(cs_fit, var = 2:5)$statistic # stat for total test

  } else if (knots == 4) {
    spline_tot <- sfsmisc::f.robftest(cs_fit, var = 2:4)$p.value # total
    spline_lin <- sfsmisc::f.robftest(cs_fit, var = 2)$p.value # linear
    spline_nonl <- sfsmisc::f.robftest(cs_fit, var = 3:4)$p.value # non linear

    spline_tot_stat <- sfsmisc::f.robftest(cs_fit, var = 2:4)$statistic # stat for total test

  } else if (knots == 3) {
    spline_tot <- sfsmisc::f.robftest(cs_fit, var = 2:3)$p.value # total
    spline_lin <- sfsmisc::f.robftest(cs_fit, var = 2)$p.value # linear
    spline_nonl <- sfsmisc::f.robftest(cs_fit, var = 3)$p.value # non linear

    spline_tot_stat <- sfsmisc::f.robftest(cs_fit, var = 2:3)$statistic # stat for total test
  }

  res <- c(spline_tot,
           spline_lin,
           spline_nonl,
           spline_tot_stat)

  names(res) <- NULL

  return(res)

}

#' Conducts non-linearity test for global methylation per exposure
#'
#' @param data A data.frame containing global methylation variable, exposure variables, confounders and technical confounders
#' @param global_meth A string defining global methylation name
#' @param exposure A string containing names of the exposures
#' @param confounders A vector of strings defining names of confounders
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#'
#' @return A data.frame with different p-values for one exposure: total, linear, non-linear and FDR corrected p-value for total (linear and non-linear associations)
#' @import dplyr
#' @importFrom tibble column_to_rownames
#' @importFrom stats as.formula
#' @importFrom sfsmisc f.robftest
#' @importFrom rms rcs

.NonLinearityGlobalMeth <- function(data,
                                    global_meth,
                                    exposure,
                                    confounders = NULL,
                                    technical_confounders = NULL,
                                    maxit) {

  # Create regression formula
  formula <-
    stats::as.formula(paste(
      global_meth,
      "~ rms::rcs(",
      exposure,
      ") +",
      paste(confounders, collapse = " + "),
      "+",
      paste(technical_confounders, collapse = " + ")
    ))


  # Fit the robust linear regression for one exposure at a time
  cs_fit <- .RobustLinearRegression(formula = formula,
                                    data = data,
                                    maxit = maxit)

  spline_tot <- sfsmisc::f.robftest(cs_fit, var = 2:5)$p.value # total
  spline_lin <- sfsmisc::f.robftest(cs_fit, var = 2)$p.value # linear
  spline_nonl <- sfsmisc::f.robftest(cs_fit, var = 3:5)$p.value # non linear

  spline_tot_stat <- sfsmisc::f.robftest(cs_fit, var = 2:5)$statistic # stat for total test

  res <- c(spline_tot,
           spline_lin,
           spline_nonl,
           spline_tot_stat)

  names(res) <- NULL

  return(res)
}
