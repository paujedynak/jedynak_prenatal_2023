# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}


#' Run robust linear regression for global methylation ~ one exposures at a time adjusted for diferent set of confounders
#'
#' @param data A data.frame containing global methylation variable, exposure variables, confounders and technical confounders
#' @param global_meth A string defining global methylation name
#' @param exposures A character vector containing names of the exposures
#' @param confounders A vector of strings defining names of confounders
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#' @param path A string defining the path to save the output
#' @param file_name A string defining specific part of the file name
#' @param display A string defining how to present the results (Beta_SE or est_CI)
#' @param save A logical indicating if to save the results of regression to a file
#'
#' @importFrom rlang .data
#' @import dplyr
#' @importFrom stats as.formula
#'
#' @return A data frame that contains regression results
#' @export
#'
GlobalMethRegression <-
  function(data,
           global_meth,
           exposures,
           confounders = NULL,
           technical_confounders = NULL,
           display = "est_CI",
           maxit,
           save = FALSE,
           path = NULL,
           file_name = NULL) {

    # Create an object to store results
    res <- data.frame()

    # For each exposure
    for (i in seq_along(exposures)) {

      # Create regression formula
      formula <-
        stats::as.formula(paste(
          global_meth,
          "~",
          exposures[i],
          "+",
          paste(confounders, collapse = " + "),
          "+",
          paste(technical_confounders, collapse = " + ")
        ))

      # Fit the robust linear regression for one exposure at a time
      fit <- .RobustLinearRegression(formula = formula,
                                     data = data,
                                     maxit = maxit)

      # Obtain regression statistics
      sfit <- .ObtainStatistics(fit = fit,
                                 data = data,
                                 exposure = exposures[i])

      # Append results for each regression for each exposure

      res <- rbind(res, sfit)
    }

    # Obtain clean regression statistics for one model
    clean_res <- .CleanResults(res = res,
                               exposures = exposures)

    if (display == "est_CI") {
      result <-
        dplyr::select(
          clean_res,
          .data$Exposure,
          .data$Estimate,
          .data$conf_low,
          .data$conf_high,
          .data$raw_p_value
        )

    } else {
      result <-
        dplyr::select(clean_res,
                      .data$Exposure,
                      .data$Beta_SE,
                      .data$raw_p_value)
    }

    if (save == TRUE) {

      # Save results to a file
      .SaveStatistics(result = result,
                      global_meth = global_meth,
                      path = path,
                      file_name)
    }

    return(result)
  }

#' Run robust linear regression for global methylation ~ one exposures at a time adjusted for diferent set of confounders
#'
#' @param data A data.frame containing global methylation variable, exposure variables, confounders and technical confounders
#' @param global_meth A string defining global methylation name
#' @param exposures A character vector containing names of the exposures
#' @param confounders A vector of strings defining names of confounders
#' @param technical_confounders A character vector defining technical confounders the regression will be adjusted to
#' @param maxit The number of iterations for each robust regression
#' @param path A string defining the path to save the output
#' @param file_name A string defining specific part of the file name
#' @param display A string defining how to present the results (Beta_SE or est_CI)
#' @param save A logical indicating if to save the results of regression to a file
#'
#' @importFrom rlang .data
#' @import dplyr
#' @importFrom stats as.formula
#'
#' @return A data frame that contains regression results
#' @export
#'
GlobalMethRegressionPhthalates <-
  function(data,
           global_meth,
           exposures,
           confounders = NULL,
           technical_confounders = NULL,
           display = "est_CI",
           maxit,
           save = FALSE,
           path = NULL,
           file_name = NULL) {

    # Create an object to store results
    res <- data.frame()

    # For each exposure
    for (i in seq_along(exposures)) {

      # Create regression formula
      formula <-
        stats::as.formula(paste(
          global_meth,
          "~",
          exposures[i],
          "+",
          paste(confounders, collapse = " + "),
          "+",
          paste(technical_confounders, collapse = " + ")
        ))

      # Fit the robust linear regression for one exposure at a time
      fit <-
        .RobustLinearRegression(formula = formula,
                                data = data,
                                maxit = maxit)

      # Obtain regression statistics
      sfit <- .ObtainStatistics(fit = fit,
                                data = data,
                                exposure = exposures[i])

      # Append results for each regression for each exposure

      res <- rbind(res, sfit)
    }

    # Obtain clean regression statistics for one model
    clean_res <- .CleanResults(res = res,
                               exposures = exposures)

    if (display == "est_CI") {
      result <-
        dplyr::select(
          clean_res,
          .data$Exposure,
          .data$Estimate,
          .data$conf_low,
          .data$conf_high,
          .data$raw_p_value
        )

    } else {
      result <-
        dplyr::select(clean_res,
                      .data$Exposure,
                      .data$Beta_SE,
                      .data$raw_p_value)
    }

    if (save == TRUE) {

      # Save results to a file
      .SaveStatistics(result = result,
                      global_meth = global_meth,
                      path = path,
                      file_name)
    }

    return(result)
  }
