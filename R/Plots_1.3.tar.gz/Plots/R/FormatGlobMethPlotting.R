# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("Model", "Exposure", "exp_lev", "gene"))
}

#' Prepares results of regression for one global methylation gene for plotting
#'
#' @param EWAS_result A data.frame with regression results for Alu or LINE-1
#' @param glob_meth_summary A string thet will be a title of each plot
#' @param expo_labels A character vector containing neat names of the exposures to be displayed on the plot
#' @param family A character vector of length of number of exposures defining a family (e.g. parabens, dichlorophenols, etc.)
#'
#' @import dplyr
#'
#' @return A data.frame for the EWAS result ready to be plotted

.Expo2FactorGlobMeth <- function(EWAS_result,
                                 glob_meth_summary,
                                 expo_labels,
                                 family) {

  data_for_plotting <- EWAS_result %>%
    dplyr::mutate(group = glob_meth_summary,
                  Family = family,
                  exp_lev = factor(Exposure, levels = Exposure, labels = expo_labels),
                  Exposure = factor(exp_lev, levels = rev(levels(exp_lev)))) %>%
    dplyr::select(-exp_lev)

  return(data_for_plotting)
}
