#' Plot ratio of hyper- and hypomethylated CpGs
#'
#' @param data A data frame with annotated regression results
#' @param ... Other arguments passed on to methods
#'
#' @return Bar plot with ratio of hyper- and hypomethylated CpGs
#' @export
#'
#' @import ggplot2
#' @importFrom rlang .data
#'
CpGStateRatio <- function(data, ...) {
  ggplot2::ggplot(data, ggplot2::aes(x = .data$CpG_state, fill = .data$CpG_state)) +
    ggplot2::facet_wrap(.data$Exposure_name ~ ., ncol = 3) +
    ggplot2::geom_bar(ggplot2::aes(x = .data$CpG_state), col = "black") +
    ggplot2::scale_fill_brewer(palette = "PuRd") +
    ggplot2::theme_bw() +
    ggplot2::xlab("") +
    ggplot2::ggtitle("") +
    ggplot2::theme(axis.line = ggplot2::element_line(colour = "black"),
                   panel.grid.major = ggplot2::element_blank(),
                   panel.grid.minor = ggplot2::element_blank(),
                   panel.border = ggplot2::element_blank(),
                   panel.background = ggplot2::element_blank(),
                   legend.position = "none")
}
