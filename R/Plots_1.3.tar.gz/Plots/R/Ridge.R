#' Draws ridge plot
#'
#' @param data A data.frame of annotated regression results
#'
#' @return A ridge plot
#'
#' @import ggplot2
#' @import ggridges
#' @importFrom rlang .data
#'
#' @export

Ridge <- function(data) {

  ridge_plot <- ggplot2::ggplot(data,
                                ggplot2::aes(x = .data$Estimate,
                                             y = .data$Gene,
                                             point_fill = .data$Gene)) +

    ggridges::geom_density_ridges(jittered_points = TRUE,
                                  scale = .95,
                                  rel_min_height = .01,
                                  point_shape = 21,
                                  point_size = 2.3,
                                  size = 0.6,
                                  position = ggridges::position_points_jitter(height = 0)) +

    ggplot2::geom_vline(xintercept = 0,
                        linetype = "dashed",
                        color = "red",
                        size = 1) +

    ggplot2::xlab(expression(beta)) +
    ggplot2::ylab("") +
    ggplot2::theme_minimal() +
    ggplot2::theme(legend.position = "none",
                   axis.text = ggplot2::element_text(size = 14),
                   axis.title.x = ggplot2::element_text(size = 20)) +

    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = 0.1))

  return(ridge_plot)
}

#' Draws dots plot for CpG beta estimates within genes
#'
#' @param data A data.frame of annotated regression results
#'
#' @return A dots plot
#' 
#' @import ggplot2
#' @importFrom rlang .data
#' 
#' @export
#'

Dots <- function(data) {
  
  dots_plot <- ggplot2::ggplot(data,
                                ggplot2::aes(x = .data$Estimate,
                                             y = .data$Gene,
                                             color = .data$Gene,
                                             fill = .data$Gene)) +
    
    ggplot2::geom_point(size = 3,
                        shape = 21,
                        color = "black") +
    
    ggplot2::geom_vline(xintercept = 0,
                        linetype = "dashed",
                        color = "red",
                        size = 1) +
    
    ggplot2::xlab(expression(beta)) +
    ggplot2::ylab("") +
    ggplot2::theme_minimal() +
    ggplot2::theme(legend.position = "none",
                   axis.text = ggplot2::element_text(size = 14),
                   axis.title.x = ggplot2::element_text(size = 20),
                   axis.text.y = ggplot2::element_text(face = "italic")) +
    
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = 0.1))
  
  return(dots_plot)
}
