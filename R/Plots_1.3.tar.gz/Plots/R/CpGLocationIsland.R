# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("..."))
}

#' Plot CpG location in relation to island
#'
#' @param data A data.frame to plot
#' @param facet_variable A name of the variable that th plot will be facetted on
#' @param x A name of the variable containing information on the methylation status (hyper-, hypo-, all sites)
#' @param y A name of the variable that contains information on the location of CpG in relation to island
#' @param ... Further arguments passed to ggplot2::facet_wrap
#'
#' @return A plot of the location of differently methylated CpGs in location to island
#' @export
#' @import ggplot2

CpGLocationIsland <- function(data, facet_variable, x, y, ...) {
  ggplot2::ggplot(data) +
    ggplot2::facet_wrap(get(facet_variable) ~ ., ncol = 3, ...) + #, scales = "free_y"
    ggplot2::geom_bar(aes(x = get(x), fill = get(y)), col = "black") +
    ggplot2::scale_fill_brewer(palette = "PuRd") +
    ggplot2::theme_bw() +
    ggplot2::labs(fill = "") +
    ggplot2::xlab("") +
    ggplot2::theme(axis.line = element_line(colour = "black"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border = element_blank(),
          panel.background = element_blank())
}
