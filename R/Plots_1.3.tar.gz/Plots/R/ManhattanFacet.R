# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}

#' Manhattan plot facetted
#'
#' @param df A data frame with 5 columns: Exposure, Chr, CpG, Position, p_value_FDR
#' @param threshold A scalar describing p value threshold
#' @param hlight A character vector listing the CpG names to highlight. Adjust color inside function. For no CpG higlighting, use NA
#' @param col A character vector listing color/colors desired for manhattan plot
#' @param title Plot title
#' @param scales A string indicating if the scale is fixed or free
#' @param extra_threshold A scalar defining if an additional horizontal line of alpha threshold is to be drawn
#' @param ... Extra arguments passed to ggplot
#'
#' @return A manhattan plot
#' @export
#'
#' @import ggplot2
#' @import dplyr
#' @importFrom ggrepel geom_label_repel
#' @importFrom rlang .data
#'
ManhattanFacet <- function(df, threshold, hlight, col, title, scales = "fixed", extra_threshold = NULL, ...){

  df_tmp <- .FormatDfFacet(df = df, hlight = hlight, threshold = threshold)

  # get chromosome center positions for x-axis
  axisdf <- .DefineAxisFacet(df_tmp = df_tmp)

  m_plot <- ggplot2::ggplot(data = df_tmp,
                            ggplot2::aes(x = .data$Position_cum, y = -log10(.data$p_value_FDR))) +

    ggplot2::facet_wrap(Exposure_name ~ .,
                        ncol = 3,
                        scales = scales) +

    # Show all points
    ggplot2::geom_point(ggplot2::aes(color = as.factor(.data$Chr)),
                        alpha = 0.8,
                        size = 2) +
    ggplot2::scale_color_manual(values = rep(col, 22)) +

    # custom X axis:
    ggplot2::scale_x_continuous(labels = axisdf$Chr,
                                breaks = axisdf$center) +
    ggplot2::scale_y_continuous(expand = c(0, 0)) + # expand = c(0,0)removes space between plot area and x axis

    # add plot and axis titles
    ggplot2::ggtitle(paste0(title)) +
    ggplot2::labs(x = "Chromosome",
                  y = bquote(~-log[10]~"(FDR-corercted p-value)")) +

    # add genome-wide sig line
    ggplot2::geom_hline(yintercept = -log10(0.05)) +
    ggplot2::geom_hline(yintercept = -log10(extra_threshold)) +

    # Add highlighted points
    ggplot2::geom_point(data = subset(df_tmp, df_tmp$is_highlight == "yes"),
                        color = "green",
                        size = 3,
                        alpha = 0.4)

  # Add label using ggrepel to avoid overlapping
  if (nrow(df_tmp[df_tmp$is_annotate == "yes", ]) > 0 &
      nrow(df_tmp[df_tmp$is_annotate == "yes", ]) < 40) {

    m_plot <- m_plot +
      ggrepel::geom_label_repel(data = df_tmp[df_tmp$is_annotate == "yes", ],
                                ggplot2::aes(label = as.factor(.data$CpG), alpha = 0.7),
                                size = 5,
                                force = 1.3)
  }

  # Customize the theme

  m_plot <- m_plot +

    ggplot2::theme_bw(base_size = 22) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5),
      legend.position = "none",
      panel.border = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_blank(),
      panel.grid.minor.x = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_text(size = 12)
    )

  return(m_plot)
}
