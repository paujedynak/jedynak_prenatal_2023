# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("Gene", "Exposure", "CpG", "X.chrom",
                           "start", "region.q", "TargetID", "CHR",
                           "MAPINFO", "Pval"))
}

#' Prepares data for plotting using the coMET plot
#'
#' @param annotated_EWAS_result A data.frame with the annotated EWAS result
#' @param meth_data A matrix containing methylation data
#' @param exposure A string defining the name of the exposure for which the plot will be drawn (as it appears in the dataset)
#' @param genes_to_search A string defining which genes are to be added to the comet plot (using grepl syntax, e.g. "^APC$|APC;|FOXG1|GNAS$|GNAS;|^GNASAS$|PEG10|SGCE")
#' @param path_to_combp A string defining the path where the *.regions-t.bed files (results of the comb-p procedure) are stored
#' @param genes_to_merge A list whose each element contains a character vector containing two elements: the first one defines names of genes whose results need to be merged and the second one the final name of the merged gene (e.g. c("GNAS|GNASAS", "GNAS_GNASAS"))
#' @param path A string defining the path to save the .bed files
#'
#' @return A set of .txt files containing "info" and "correlation" for CpGs of interest
#' @export
#' @import dplyr
#' @importFrom Helpers CpGsInGenes
#' @importFrom utils write.table
#' @importFrom stats cor
#' @importFrom utils read.delim
#' @importFrom here here

PreapareCometPlot <- function(annotated_EWAS_result,
                              meth_data,
                              exposure,
                              genes_to_search,
                              path_to_combp,
                              genes_to_merge,
                              path) {

  # Create "info" file plugged into the coMET plot
  # Extract information for the comet plot from the EWAS (CpG, starting position and gene)
  EWAS_info <- annotated_EWAS_result %>%

    # Filter results for TCS and imprinted genes only
    dplyr::filter(Exposure == exposure & grepl(genes_to_search, Gene)) %>%
    dplyr::select(CpG, Position, Gene) %>%
    dplyr::rename(TargetID = CpG, MAPINFO	= Position)


  # Extract information for the comet plot from the EWAS (CpG, starting position and gene)
  # Read the fdr file for TCS that contains information needed for comet plot and select variables of interest
  fdr_info <- utils::read.delim(here::here(path_to_combp)) %>%
    dplyr::select(X.chrom, start, region.q) %>%
    dplyr::rename(CHR = X.chrom, MAPINFO = start, Pval = region.q)

  # Match the info about CpGs for imprinted genes and the rest of the information from the fdr file
  comet_info <- merge(fdr_info, EWAS_info, by = "MAPINFO") %>%
    dplyr::select(TargetID, CHR, MAPINFO, Pval, Gene) %>%
    Helpers::CpGsInGenes(var_to_distinct = "TargetID")

  if (length(genes_to_merge) > 0) {
    for (item in genes_to_merge) {

      comet_info <- dplyr::mutate(comet_info, Gene = dplyr::case_when(grepl(item[1], Gene) ~ item[2],
                                                          TRUE ~ Gene))
    }
  }

  comet_info <- comet_info %>%

    # Arrange by position of the CpG as required by the comet plot
    dplyr::arrange(MAPINFO)

  # Save results for each gene to a separate file
  comet_info %>%
    dplyr::group_by(Gene) %>%
    dplyr::group_walk(~ utils::write.table(.x,
                                           file = here::here(path, paste0(.y$Gene, "_info.txt")),
                                           sep = "\t",
                                           row.names = FALSE,
                                           quote = FALSE))

  # Create "correlation" file plugged into the coMET plot
  for (gene in unique(comet_info$Gene)) {

    # Extract positions of each gene
    CpG_per_gene <- dplyr::filter(comet_info, Gene == gene) %>%
      dplyr::pull(TargetID)

    # For each CpG located in a position obtained in the previous step,
    # extract information on the methylation level
    meth_vector <- meth_data[, CpG_per_gene]

    # Run Spearman correlation for the selected CpGs
    cm <- stats::cor(meth_vector, method = "spearman", use = "complete.obs")

    # Save results for each gene to a separate file
    utils::write.table(cm, file = here::here(path, paste0(gene, "_corr.txt")),
                       sep = "\t",
                       row.names = FALSE,
                       quote = FALSE)
  }

  return(comet_info)
}
