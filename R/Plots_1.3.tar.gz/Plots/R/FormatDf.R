# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}

#' Format data.frame for manhattan plot
#'
#' @param df A data frame with 5 columns: Exposure, Chr, CpG, Position, p_value
#' @param threshold A scalar describing p value threshold
#' @param hlight A character vector listing the CpG names to highlight. Adjust color inside function. For no CpG higlighting, use NA
#'
#' @return A data.frame formatted for manhattan plot
#' @import dplyr
#' @importFrom rlang .data

.FormatDf <- function(df, hlight, threshold) {

  # format df
  df_tmp <- df %>%

    # Compute chromosome size
    dplyr::group_by(.data$Chr) %>%
    dplyr::summarise(chr_len = max(.data$Position)) %>%

    # Calculate cumulative position of each chromosome
    dplyr::mutate(tot = cumsum(as.numeric(.data$chr_len)) - .data$chr_len) %>%
    dplyr::select(-.data$chr_len) %>%

    # Add this info to the initial dataset
    dplyr::left_join(df, ., by = c("Chr" = "Chr")) %>%

    # Add a cumulative position of each SNP
    dplyr::arrange(.data$Chr, .data$Position) %>%
    dplyr::mutate(Position_cum = .data$Position + .data$tot) %>%

    # Add highlight and annotation information
    dplyr::mutate(is_highlight = ifelse(.data$CpG %in% hlight, "yes", "no")) %>%
    dplyr::mutate(is_annotate = ifelse(.data$p_value_FDR < threshold, "yes", "no"))

  return(df_tmp)
  }
