#' Get chromosome center positions for x-axis
#'
#' @param df_tmp A data.frame formattd for a manhattan plot
#' @importFrom rlang .data
#'
#' @return Returns a number defining center of the axis

.DefineAxisFacet <- function(df_tmp) {
  axisdf <- df_tmp %>%
    dplyr::group_by(.data$Chr) %>%
    dplyr::summarize(center = (max(.data$Position_cum) + min(.data$Position_cum) ) / 2 )

  return(axisdf)
}
