#' Draws a plot of beta estimates with CIs
#'
#' @param data A data.frame of estimates with CIs
#' @param xlim Limits of X axis
#' @param title A string defining the title of the plot
#'
#' @return A plot of estimates with CIs colour-grouped by family of exposure
#' @export
#'
EstimatesGlobalMeth <- function(data, xlim, title) {

  plot <- ggplot2::ggplot(data, ggplot2::aes(.data$Estimate, .data$Exposure,
                                             color = .data$Family,
                                             fill = .data$Family)) +
    ggplot2::facet_wrap(~.data$group) +
    ggplot2::geom_vline(xintercept = 0,
                        linetype = "dashed",
                        color = "red",
                        size = 1) +
    ggplot2::geom_errorbarh(ggplot2::aes(xmin = .data$conf_low,
                                xmax = .data$conf_high),
                            height = 0.4,
                            size = 1) +
    ggplot2::geom_point(size = 3,
                        shape = 21,
                        color = "black") +
    ggplot2::xlim(xlim) +
    ggplot2::xlab(expression(beta)) +
    ggplot2::ylab("") +
    ggplot2::ggtitle(title) +
    ggplot2::theme_bw() +
    ggplot2::theme(text = ggplot2::element_text(size = 16),
                   strip.text = ggplot2::element_text(face = "italic"),
                   axis.text.x = ggplot2::element_text(size = 12),
                   axis.text.y = ggplot2::element_text(size = 12),
                   plot.title = ggplot2::element_text(face = "bold"),
                   legend.position = "none")

  return(plot)
}
