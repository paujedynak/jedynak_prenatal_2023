#' Draw volcano plot
#'
#' @param data A data.frame with annotated regression results:
#' must contain columns called:
#' "Estimate" which is a regression estimate to be plotted,
#' "p_value_FDR" which is a corrected p value to be plotted,
#' "Exposure_name" which defines which exposure was used for regression (e.g. "triclosan"),
#' "Significant" categorical variable which contains values "Not significant" and "Significant".
#'  Optionally, if the name of gene is to be plotted above the estimate, provide a column "Gene" with gene names
#' @param extra_threshold A scalar defining if an additional horizontal line of alpha threshold is to be drawn
#'
#' @return Volcano plot
#' @export
#'
#' @import ggplot2
#' @importFrom rlang .data
#'
Volcano <- function(data, extra_threshold = 0.05) {

  plot_volc <- ggplot2::ggplot(data, ggplot2::aes(x = .data$Estimate, y = -log10(.data$p_value_FDR))) +
    ggplot2::facet_wrap(ggplot2::vars(.data$Exposure_name), ncol = 3) +
    ggplot2::geom_point(ggplot2::aes(color = .data$Significant)) +
    ggplot2::scale_color_manual(values = c("grey", "red"), name = "Significance") +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::theme(legend.position = "bottom") +
    ggplot2::geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "red") +
    ggplot2::geom_hline(yintercept = -log10(extra_threshold), linetype = "dashed", color = "red") +
    ggplot2::ylab(bquote(~-log[10]~"(FDR-corrected p-value)")) +
    ggplot2::xlab(expression(beta))

  # If the number of selected genes is low (maybe 10 max), gene labels can be added to the plot
  # + ggrepel::geom_text_repel(
  #   data = dplyr::filter(data, .data$p_value_FDR < 0.05),
  #   ggplot2::aes(label = .data$Gene),
  #   size = 5,
  #   box.padding = unit(0.35, "lines"),
  #   point.padding = unit(0.3, "lines")
  # )

  return(plot_volc)
}


#' Draw volcano plot for CpGs within a DMR
#'
#' @param data A data.frame with annotated regression results: must contain columns called "Estimate" which is a regression estimate to be plotted, "p_value_FDR" which is a corrected p value to be plotted, "Exposure_name" which defines which exposure was used for regression (e.g. "triclosan"), "Significant" categorical variable which contains values "Not significant" and "Significant". Optionally, if the name of gene is to be plotted above the estimate, provide a column "Gene" with gene names
#'
#' @return Volcano plot for CpGs within genes detected in DMRs
#' @export
#'
#' @import ggplot2
#' @importFrom rlang .data
#'
VolcanoDMR <- function(data) {

  plot_volc_DMR <- ggplot2::ggplot(data,
                                   ggplot2::aes(x = .data$Estimate,
                                                y = -log10(.data$raw_p_value))) +
    ggplot2::facet_wrap(ggplot2::vars(.data$Exposure_name), ncol = 3) +
    ggplot2::geom_point(ggplot2::aes(fill = .data$Gene),
                        colour = "black",
                        shape = 21,
                        size = 3) +
    ggplot2::scale_fill_brewer(palette = "Paired") +
    ggplot2::geom_hline(yintercept = -log10(0.05),
                        linetype = "dashed",
                        color = "black") +
    ggplot2::geom_vline(xintercept = 0,
                        linetype = "dashed",
                        color = "black") +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::ylab(bquote(~-log[10]~"p-value")) +
    ggplot2::xlab(expression(beta)) +
    theme(legend.position="bottom",
          legend.text = element_text(face = "italic"))

  return(plot_volc_DMR)
}
