#' Draws QQ plot
#'
#' @param dataset A data.frame of annotated regression results
#' @param exposure_name A string naming the exposure for which the plot will b drawn
#' @param plot_cutoff_p p cut off value, default = 0.05
#'
#' @return A qq plot
#' @export
#' @import QCEWAS
#' @import graphics
#' @importFrom bacon bacon
#' @importFrom bacon inflation
#' @importFrom grDevices rgb
#' @importFrom stats qbeta
#'
QQ <- function(dataset, exposure_name, plot_cutoff_p = 0.05) {

  QQ_obs_p <- dataset$P_VAL
  QQ_obs_N <- length(QQ_obs_p)

  lambda <- QCEWAS::P_lambda(QQ_obs_p) %>%
    round(2)

  t_stats <- stats::qt(p = dataset$P_VAL, df = 173, lower.tail = FALSE)

  BIF <- bacon::bacon(teststatistics = t_stats) %>%
    bacon::inflation() %>%
    round(2)

  QQ_obs_p <- sort(-log10(QQ_obs_p))
  QQ_incl <- QQ_obs_p >= -log10(plot_cutoff_p)

  QQ_exp <- sort(-log10(stats::ppoints(QQ_obs_N)))
  QQ_exp_short <- QQ_exp[QQ_incl]
  QQ_obs_p <- QQ_obs_p[QQ_incl]
  QQ_exp_min <- QQ_exp_short[1]
  QQ_exp_max <- QQ_exp_short[length(QQ_exp_short)]
  QQ_obs_min <- QQ_obs_p[1]
  QQ_obs_max <- QQ_obs_p[length(QQ_obs_p)]

  temp <- (seq_len(QQ_obs_N))
  i1000 <- c(1, (seq_len(1000)) * floor(QQ_obs_N/1000), QQ_obs_N)
  QQ_band_upper <- sort(-log10(stats::qbeta(1 - 0.05/2, temp, QQ_obs_N - temp + 1)))[i1000]
  QQ_band_lower <- sort(-log10(stats::qbeta(0.05/2, temp, QQ_obs_N - temp + 1)))[i1000]
  QQ_exp <- QQ_exp[i1000]

  plotit <- function(QQ_exp_min, QQ_exp_max, exposure_name, QQ_exp, QQ_band_upper, QQ_band_lower, QQ_obs_p, lambda, BIF) {

    graphics::plot(c(QQ_exp_min, QQ_exp_max), c(QQ_obs_min, QQ_obs_max),
                   xlim = c(0, QQ_exp_max),
                   ylim = c(0, 8),
                   main = exposure_name,
                   xlab = "Expected -log10(p-value)",
                   ylab = "Observed -log10(p-value)",
                   pch = 1,
                   col = "black",
                   cex.sub = 1.3)

    graphics::polygon(c(QQ_exp, rev(QQ_exp)), c(QQ_band_upper, rev(QQ_exp)),
                      col = grDevices::rgb(1, 0, 0, 0.5),
                      border = NA)
    graphics::polygon(c(QQ_exp, rev(QQ_exp)), c(QQ_band_lower, rev(QQ_exp)),
                      col = grDevices::rgb(1, 0, 0, 0.5),
                      border = NA)

    graphics::points(QQ_obs_p, QQ_obs_p, pch = 1, col = "black")
    graphics::abline(0, 1)
    graphics::text(0, 7, substitute(paste(lambda, " = ", x), list(x = round(lambda, digits = 3))), pos = 4)
    graphics::text(0, 6, substitute(paste(BIF, " = ", x), list(x = round(BIF, digits = 3))), pos = 4)
  }

  final_plot <- function(){
    plotit(QQ_exp_min, QQ_exp_max, exposure_name, QQ_exp, QQ_band_upper, QQ_band_lower, QQ_obs_p, lambda, BIF)
  }

  return(final_plot())
}
