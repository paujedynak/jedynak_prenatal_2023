
#' Prepares results of regression for Alu and LINE-1 genes for plotting
#'
#' @param global_meth_char A data.frame containing statistics (mean and sd) for Alu or LINE-1
#' @param EWAS_Alu A data.frame with regression results for Alu
#' @param EWAS_LINE_1 A data.frame with regression results for LINE-1
#' @param expo_labels A character vector containing neat names of the exposures to be displayed on the plot
#' @param family A character vector of length of number of exposures defining a family (e.g. parabens, dichlorophenols, etc.)
#'
#' @return A data.frame for the EWAS results for Alu and LINE-1 ready to be plotted
#' @export
#' @import dplyr

GlobMethPlotting <- function(global_meth_char,
                             EWAS_Alu,
                             EWAS_LINE_1,
                             expo_labels,
                             family) {

  # Create a header for the Alu and LINE-1 plots
  alu_summary <- paste0("Alu: ", dplyr::filter(global_meth_char,
                                               gene == "alumed")[2],
                        "% ",
                        "(",
                        "±",
                        dplyr::filter(global_meth_char,
                                      gene == "alumed")[3],
                        "%)")

  line_1_summary <- paste0("LINE-1: ", dplyr::filter(global_meth_char,
                                                     gene == "linemed")[2],
                           "% ",
                           "(±",
                           dplyr::filter(global_meth_char,
                                         gene == "linemed")[3],
                           "%)")

  # Transform exposure into factor (to be able to order plot axis by exposure Family name)
  data_alu <- .Expo2FactorGlobMeth(EWAS_result = EWAS_Alu,
                                   glob_meth_summary = alu_summary,
                                   expo_labels = expo_labels,
                                   family = family)

  data_line <- .Expo2FactorGlobMeth(EWAS_result = EWAS_LINE_1,
                                    glob_meth_summary = line_1_summary,
                                    expo_labels = expo_labels,
                                    family = family)

  # Merge Alu and LINE-1 regression results
  data_both <- dplyr::bind_rows(data_alu, data_line)

  return(data_both)
}
