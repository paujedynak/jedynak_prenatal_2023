#' Draws comet plot
#'
#' @param genes A string defining the names of genes for which comet plots will be drawn
#' @param path_to_info A string defining location where "info", "correlation" and "config" files for each gene are stored
#'
#' @return A comet plot for each gene. The plots are saved in PDF in the main directory of the project.
#' @export
#' @importFrom coMET comet.web
#' @importFrom here here

coMET <- function(genes,
                  path_to_info) {

  # For each gene of interest draw a comet plot
  for (gene in genes) {

    # Define path to the config file (this file has to be prepared manually basing on a template)
    comet_config_file <- list.files(path = here::here(path_to_info), pattern = paste0(gene, "_config.txt"))

    # Define path to the info file
    comet_info_file <- list.files(path = here::here(path_to_info), pattern = paste0(gene, "_info.txt"))

    # Define path to the correlation matrix file
    comet_corr_file <- list.files(path = here::here(path_to_info), pattern = paste0(gene, "_corr.txt"))

    # Draw comet plot for each gene
    coMET::comet.web(config.file = here::here(path_to_info, comet_config_file),
                     mydata.file = here::here(path_to_info, comet_info_file),
                     cormatrix.file = here::here(path_to_info, comet_corr_file),
                     print.image = TRUE,
                     verbose = FALSE)
  }
  return()
}
