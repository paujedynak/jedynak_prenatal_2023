# quiets concerns of R CMD check re: the .'s that appear in pipelines
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}

#' Manhattan plot
#'
#' @param df A data frame with 4 columns: Chr, CpG, Position, p_value
#' @param threshold A scalar describing p value threshold
#' @param hlight A character vector listing the CpG names to highlight. Adjust color inside function. For no CpG higlighting, use NA
#' @param col A character vector listing color/colors desired for manhattan plot
#' @param ylims Limits of the Y axis
#' @param title Plot title
#'
#' @return A manhattan plot
#' @export
#'
#' @import ggplot2
#' @import dplyr
#' @importFrom ggrepel geom_label_repel
#' @importFrom rlang .data

Manhattan <- function(df, threshold, hlight, col, ylims = NULL, title) {

  df_tmp <- .FormatDf(df = df, hlight = hlight, threshold = threshold)

  # get chromosome center positions for x-axis
  axisdf <- .DefineAxis(df_tmp)

  m_plot <- ggplot2::ggplot(df_tmp, aes(x = .data$Position_cum, y = -log10(.data$p_value_FDR))) +

    # Show all points
    ggplot2::geom_point(aes(color = as.factor(.data$Chr)), alpha = 0.8, size = 2) +
    ggplot2::scale_color_manual(values = rep(col, 22)) +

    # custom X axis:
    ggplot2::scale_x_continuous(labels = axisdf$Chr, breaks = axisdf$center) +
    ggplot2::scale_y_continuous(expand = c(0, 0), limits = NULL) + # expand = c(0,0)removes space between plot area and x axis

    # add plot and axis titles
    ggplot2::ggtitle(paste0(title)) +
    ggplot2::labs(x = "Chromosome", y = "-log10(p value)") +

    # add genome-wide sig line
    ggplot2::geom_hline(yintercept = -log10(0.05)) +

    # Add highlighted points
    ggplot2::geom_point(data = subset(df_tmp, df_tmp$is_highlight == "yes"), color = "green", size = 2, alpha = 0.4)

  # Add label using ggrepel to avoid overlapping
  if (nrow(df_tmp[df_tmp$is_annotate == "yes", ]) > 0 &
      nrow(df_tmp[df_tmp$is_annotate == "yes", ]) < 20) {
    m_plot <- m_plot +
      ggrepel::geom_label_repel(data = df_tmp[df_tmp$is_annotate == "yes", ], aes(label = as.factor(.data$CpG), alpha = 0.7), size = 5, force = 1.3)
  }

  # Customize the theme
  m_plot <- m_plot +

    ggplot2::theme_bw(base_size = 22) +
    ggplot2::theme(
      plot.title = element_text(hjust = 0.5),
      legend.position = "none",
      panel.border = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),
      axis.text.x = element_text(size = 12)
    )

  return(m_plot)
}
